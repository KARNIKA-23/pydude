with open("input.txt", "r") as f:
    content = f.read()

with open("output.txt", "w") as f:
    f.write(content.upper())